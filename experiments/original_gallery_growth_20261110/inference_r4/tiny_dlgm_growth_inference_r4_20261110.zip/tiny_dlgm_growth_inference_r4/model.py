"""Tested DLGM depth-growth model. CPU full-sequence inference; no cache."""
import hashlib
import torch
from torch import nn
from torch.nn import functional as F
from cpu_adapter import load

COUNTS = {1: 31032, 2: 45649, 3: 60266}
SOURCE = None

def keyed_seed(seed, name):
    return int.from_bytes(hashlib.sha256(f'parameter-trickle-r1/{seed}/{name}'.encode()).digest()[:8], 'big') % (2**63-1)

def canonical(seed, name, constructor):
    # fork_rng restores the global stream, independently of the data generator.
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(keyed_seed(seed, name))
        return constructor()

class RMSNorm(nn.Module):
    def __init__(self, width=32):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(width))
    def forward(self, x):
        return x * torch.rsqrt(x.square().mean(-1, keepdim=True) + 1e-6) * self.weight

class Block(nn.Module):
    def __init__(self, seed, index):
        super().__init__()
        global SOURCE
        if SOURCE is None:
            SOURCE = load('458')
        prefix = f'blocks.{index}'
        self.n1 = canonical(seed, prefix+'.n1', RMSNorm)
        self.mix = canonical(seed, prefix+'.mix', lambda: SOURCE.DeltaNet(hidden_size=32, num_heads=2, layer_idx=index))
        self.n2 = canonical(seed, prefix+'.n2', RMSNorm)
        self.gate = canonical(seed, prefix+'.gate', lambda: nn.Linear(32,64,bias=False))
        self.up = canonical(seed, prefix+'.up', lambda: nn.Linear(32,64,bias=False))
        self.down = canonical(seed, prefix+'.down', lambda: nn.Linear(64,32,bias=False))
    def forward(self, x):
        y, aux, cache = self.mix(self.n1(x))
        assert aux is None and cache is None
        x = x + y
        z = self.n2(x)
        return x + self.down(F.silu(self.gate(z)) * self.up(z))

class LM(nn.Module):
    def __init__(self, seed, depth=1, gate_value=0.):
        super().__init__()
        assert depth in COUNTS
        self.seed = seed
        self.emb = canonical(seed,'emb',lambda: nn.Embedding(256,32))
        self.blocks = nn.ModuleList([Block(seed,0)])
        self.growth_gates = nn.ParameterDict()
        self.norm = canonical(seed,'norm',RMSNorm)
        self.head = canonical(seed,'head',lambda: nn.Linear(32,256,bias=False))
        for _ in range(1,depth):
            self.append_block(gate_value)
        assert sum(p.numel() for p in self.parameters()) == COUNTS[depth]
    def append_block(self, gate_value=0., block=None):
        index = len(self.blocks)
        assert index in (1,2)
        self.blocks.append(Block(self.seed,index) if block is None else block)
        self.growth_gates[str(index)] = nn.Parameter(torch.tensor(float(gate_value),dtype=torch.float32))
        assert sum(p.numel() for p in self.parameters()) == COUNTS[len(self.blocks)]
    def forward(self, x):
        x = self.emb(x)
        x = self.blocks[0](x)
        for index in range(1,len(self.blocks)):
            proposed = self.blocks[index](x)
            assert bool(torch.isfinite(proposed).all()), 'Nonfinite zero-gated branch'
            x = x + self.growth_gates[str(index)] * (proposed-x)
        return self.head(self.norm(x))

def build(seed, arm, depth=None):
    assert arm in ('S','L','Z','G','R') and seed in (1,2,3,99)
    if depth is None:
        depth = 3 if arm in ('L','Z') else 1
    return LM(seed,depth,1. if arm=='L' else 0.)

def lr(update_index):
    return .003 * min(1., (update_index+1)/32.)

def initialize_adam_state(optimizer):
    for group in optimizer.param_groups:
        for p in group['params']:
            if p not in optimizer.state or not optimizer.state[p]:
                optimizer.state[p] = dict(step=torch.tensor(0.,dtype=torch.float32),
                                          exp_avg=torch.zeros_like(p),exp_avg_sq=torch.zeros_like(p))

def optimizer_for(model, current_lr=None):
    named = dict(model.named_parameters())
    groups = []
    for stage in range(len(model.blocks)):
        names = [n for n in named if birth_stage(n)==stage]
        groups.append(dict(params=[named[n] for n in names],names=names,birth_stage=stage,
                           birth_update=0,lr=lr(0) if current_lr is None else current_lr))
    optimizer = torch.optim.AdamW(groups,lr=.003,betas=(.9,.999),eps=1e-8,
                                  weight_decay=.01,foreach=False,fused=False)
    initialize_adam_state(optimizer)
    return optimizer

def birth_stage(name):
    if name.startswith('growth_gates.'):
        return int(name.split('.')[1])
    if name.startswith('blocks.'):
        return int(name.split('.')[1])
    return 0

def add_optimizer_group(optimizer, model, old_names, completed_updates):
    pairs = [(n,p) for n,p in model.named_parameters() if n not in old_names]
    optimizer.add_param_group(dict(params=[p for _,p in pairs],names=[n for n,_ in pairs],
                                   birth_stage=len(model.blocks)-1,birth_update=completed_updates,
                                   lr=lr(max(0,completed_updates-1))))
    initialize_adam_state(optimizer)

def forward(model, x):
    with torch.autocast('cpu',dtype=torch.bfloat16):
        return model(x)
