"""Compare loaded model logits against saved original-checkpoint reference outputs."""
import json,hashlib
from pathlib import Path
import numpy as np
import torch
from load_model import load_model,full_recompute

def main():
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    root=Path(__file__).resolve().parent
    manifest=json.loads((root/'CHECKPOINTS.json').read_text())
    for path,expected in manifest['required_file_sha256'].items():
        assert hashlib.sha256((root/path).read_bytes()).hexdigest()==expected,path
    rows=[]
    for item in manifest['checkpoints']:
        model,_=load_model(item['name'],manifest)
        for fixture in manifest['fixtures']:
            actual=full_recompute(model,fixture['byte_values']).numpy()
            expected=np.load(root/item['reference_outputs'][fixture['name']],allow_pickle=False)
            assert np.array_equal(actual,expected),(item['name'],fixture['name'])
            rows.append({'checkpoint':item['name'],'fixture':fixture['name'],'max_absolute_error':0.0,'exact':True})
    result={'status':'PASS','comparisons':rows,'count':len(rows),'scope':'CPU BF16 full recompute; fixed public byte inputs; no training or cached decoding.'}
    print(json.dumps(result,sort_keys=True))
if __name__=='__main__':main()
