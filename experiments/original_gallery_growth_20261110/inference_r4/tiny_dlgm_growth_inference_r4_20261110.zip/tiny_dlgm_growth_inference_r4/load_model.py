"""Load model-only, pickle-free NumPy tensor checkpoints for full recompute."""
import json
from pathlib import Path
import numpy as np
import torch
from model import build

def load_model(checkpoint, manifest=None):
    root=Path(__file__).resolve().parent
    manifest=manifest or json.loads((root/'CHECKPOINTS.json').read_text())
    item=next(x for x in manifest['checkpoints'] if x['name']==checkpoint)
    model=build(item['seed'],item['arm'],item['depth'])
    state={}
    with np.load(root/item['weights_file'],allow_pickle=False) as arrays:
        assert set(arrays.files)==set(item['tensor_schema'])
        for name in arrays.files:
            a=arrays[name]; spec=item['tensor_schema'][name]
            assert a.dtype==np.dtype(spec['numpy_dtype']) and list(a.shape)==spec['shape']
            assert a.dtype==np.float32 and np.isfinite(a).all()
            state[name]=torch.from_numpy(a.copy())
    model.load_state_dict(state,strict=True)
    assert sum(p.numel() for p in model.parameters())==item['parameters']
    model.eval()
    return model,item

def full_recompute(model, byte_values):
    values=torch.tensor([list(byte_values)],dtype=torch.long)
    assert values.shape[1]>0 and bool(((values>=0)&(values<256)).all())
    with torch.no_grad(),torch.autocast('cpu',dtype=torch.bfloat16):
        return model(values).float()

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser(description='Full-recompute byte logits. No KV/recurrent cache or training resume.')
    p.add_argument('--checkpoint',default='G_seed1_cpu60')
    p.add_argument('--text',default='A small public byte sequence for model loading.')
    a=p.parse_args();torch.set_num_threads(1);torch.set_num_interop_threads(1)
    m,metadata=load_model(a.checkpoint);logits=full_recompute(m,a.text.encode('utf-8'))
    print(json.dumps({'checkpoint':a.checkpoint,'shape':list(logits.shape),'finite':bool(torch.isfinite(logits).all()),'last_byte_argmax':int(logits[0,-1].argmax()),'cache':'unsupported'}))
