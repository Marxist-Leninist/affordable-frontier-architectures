# Attribution and dependency scope

The original #458 DualScaleMemoryRouter source in original/458_delta_net_dlgm.py is copied byte-for-byte from ASI-Arch commit 3113c51b04a1d4a7520a3b0238c6a08d3194d58f, data/106.json (Git blob e403531e663cf24c800002720d293cccf77f94df). Its SHA-256 is 76412d2f7aff30f99ce7089e0f57f8ef26add7f2d9f965adf8650a00538bd1f5. ASI-Arch is Apache-2.0; the unchanged license is original/ASI_ARCH_LICENSE. The inherited upstream MIT notice for Songlin Yang is retained at original/LICENSE. No new license or permission change is made here.

Source: https://github.com/GAIR-NLP/ASI-Arch/blob/3113c51b04a1d4a7520a3b0238c6a08d3194d58f/data/106.json
Paper: https://arxiv.org/abs/2507.18074

model.py and cpu_adapter.py are the actual study wrapper and narrow CPU adapters. Only model.py's first docstring changes for presentation; the remaining AST is unchanged. cpu_adapter.py is unchanged and strips only top-level torch.compile decorators when loading the original source. These adapters do not establish numerical parity with official fused FLA kernels. External dependencies are installed separately: PyTorch (BSD-style), NumPy (BSD-3-Clause), einops (MIT). No third-party package binaries are redistributed.
