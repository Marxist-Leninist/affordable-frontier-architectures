# Tiny DLGM growth models: standalone inference export

**Local prepared package; not yet published.** This export contains runnable model code and 17 model-only checkpoints from the completed R4 study. It is not a release of all historical architectures, all study checkpoints, or the original training/accounting infrastructure.

## Included

- The 15 final CPU-60 checkpoints: S, L, Z, G and R, each at seeds 1, 2 and 3.
- Two additional seed-1 G boundary states: immediately before and after the first growth, at update 64 / 32,768 byte targets. These are depth 1 / 31,032 parameters and depth 2 / 45,649 parameters. Final G models have depth 3 / 60,266 parameters.
- Exact original #458 DualScaleMemoryRouter source, the actual tested wrapper and CPU adapter, retained upstream license notices, a standalone loader, public-byte fixtures and a strict validation script.
- CHECKPOINTS.json: architecture, arm, seed, actual depth/parameter count, update/token count, exact source-state identity and hash, learned growth gates, tensor schema, metric lineage and file hashes.

S is fixed small. L is fixed large with gates initially one. Z is fixed large with added gates initially zero. G adds zero-gated blocks while preserving learned parameters and Adam state during the original study. R uses the same growth schedule but resets all parameters and Adam state at each boundary. All models use a 256-byte vocabulary, width 32, two heads and FFN width 64. The original growth targets were 32,768 and 98,304 completed byte targets. This package does not introduce a 31k-parameter Transformer control.

## Format and prerequisites

Checkpoint files are **NumPy NPZ archives**, not safetensors and not pickle-bearing PyTorch training checkpoints. They contain only finite FP32 model tensors. Loading uses numpy.load(..., allow_pickle=False). Optimizer state, RNG state, sampler state, raw corpus text, private trainers and internal run records are not included.

The tested dependencies are Python 3.12.14, PyTorch 2.6.0+cpu, NumPy 2.3.5 and einops 0.8.1. Exact observed Python version is recorded in CHECKPOINTS.json. These packages are not vendored. Use an isolated environment; obtain PyTorch CPU wheels from the official PyTorch CPU wheel index and the other packages from their standard package registry. requirements.txt records the tested versions. No installation is performed by the loader.

Stored weights remain FP32. The tested reference runs use **CPU BF16 autocast**, and saved fixture outputs are exact FP32 casts of those BF16 logits. Plain FP32 output parity, other PyTorch versions, different CPU arithmetic and GPU operation have not been validated. The CPU adapter supplies narrow FLA substitutes; it is not official fused-kernel numerical parity and should run in an isolated process rather than alongside a real FLA installation.

## Run

From this extracted directory, after installing the listed dependencies:

```sh
python validate.py
python load_model.py --checkpoint G_seed1_cpu60 --text "A small public byte sequence."
```

The first command verifies required file hashes and exact output parity for all 17 models on two public fixtures, at lengths 32 and 128. The second loads a model and reports full-recompute logit shape, finiteness and the final byte argmax. It is a tiny byte-level research model, not an instruction-following assistant.

For Python use, load_model.load_model(name) returns the model and metadata. load_model.full_recompute(model, byte_values) produces logits under the tested CPU BF16 autocast setting. See CHECKPOINTS.json for exact names. Full sequence inputs must contain byte values 0–255. **Cached decoding is unsupported.** No serving or GPU path is provided.

## What was checked

All 17 original checkpoints were hash-verified before and after export. Each original model's nonparameter runtime attributes and all buffers matched its fresh standalone constructor exactly. Model tensors were exported without changing values. A fresh isolated interpreter then loaded only this package, standard libraries and the pinned installed dependencies: all 34 full-recompute comparisons were exactly equal, with maximum absolute error 0. The two first-growth boundary reference outputs were also exactly equal on both fixtures.

Reference outputs were newly computed from the immutable original checkpoints on fixed public/nonprivate byte inputs solely for export validation. They are not newly measured study-heldout results. The fixed-input test does not prove equivalence for every possible input or hardware environment. validate.py deliberately does not relax the exact tolerance when there is a mismatch.

The separate bounded export validation passed on its first attempt, with guarded accounting of 10.569376575 CPU seconds and 14.511103615 active-wall seconds, below the 30/60 limits, and peak sampled aggregate RSS 295.605 MiB. These figures include a conservative preparation/finalization allowance, are not exact physical consumption, and are not a model speed benchmark. The completed scientific study's accounting was not reset or replaced.

## Replication boundary

This package supports reloading the tested model math and these exact inference states, inspecting actual depth-growth gates and reproducing the saved public-fixture logits on the tested stack. model.py retains the tested construction and growth helpers; its first docstring alone was rewritten for presentation. All remaining model AST, cpu_adapter.py and original source bytes are unchanged.

It does **not** reproduce complete training, deterministic optimizer/RNG resume, the full study data sampler and exclusions, all boundary states, the 131,072-target-token checkpoint cohort, or the original runtime/resource-accounting wrappers. No fresh training or corpus evaluation was performed for this export. Model-only files cannot resume the original optimizer. Reproducing the paper-scale model or official FLA training is outside its scope.

The included discovery metrics are copied from the verified original study records, not recomputed here. Reused heldouts and three seeds do not establish a universal growth winner. At CPU-60, G beat destructive-reset R but S had lower WikiText loss in all seeds; G versus L was seed-sensitive. See the [verified method/results report](https://github.com/Marxist-Leninist/affordable-frontier-architectures/blob/3e7185b7643dcbf4ac6554e59a643ef79e885913/experiments/original_gallery_growth_20261110/README.md).

## Attribution and integrity

See NOTICE.md and the two unchanged license files in original/. The original #458 source is Apache-2.0 at ASI-Arch commit 3113c51b04a1d4a7520a3b0238c6a08d3194d58f. No repository license, visibility or permissions are changed by this local preparation. SHA256SUMS.json binds every export file except itself. There is no code, model, data or configuration from private native trainers in this package.
