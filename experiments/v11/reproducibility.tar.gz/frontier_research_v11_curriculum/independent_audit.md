# Independent curriculum adequacy audit

## Verified design and data

The curriculum is explicitly exploratory and validation-only, motivated by the previous frozen experiment's failure to learn. It does not replace that result. Each architecture and learning rate starts a fresh seed-101 model with fresh Adam, rather than continuing an extension checkpoint. The two learning rates are 0.001 and 0.003.

I independently verified frozen source and protocol hashes, all 6,000 minibatch digests, and the complete shared staged schedule: 1,000 steps at length 64/four facts; 1,000 at length 128/four or eight facts; 4,000 at lengths 128/256/512 and four/eight/sixteen facts. Each run has 48,000 supervised examples and 11,129,856 input-token presentations. Four runs therefore consume 192,000 examples and 44,519,424 input-token presentations. Matching batches and token counts does not imply equal FLOPs, compute cost, inference memory, or optimization difficulty.

Validation uses the new seed base 410000, with 128 examples in each of nine length/fact-count cells. I regenerated saved validation hashes independently. Test seed base 820000 is reserved and never passed to an evaluation call in this pilot. There are no test metrics in the pilot results. Different random seeds separate these samples procedurally, but the task generator and synthetic distribution are shared.

The driver saves checkpoints and evaluates every 1,000 steps while completing all 6,000 updates for every architecture/rate regardless of progress. Learning-rate selection uses pooled validation CE only at final step 6,000, with lower-rate tie-breaking; it does not choose the best epoch. The identical adequacy gate is independently applied to each architecture: pooled validation accuracy at least 80%, and length-512/sixteen-fact accuracy at least 70%. Passing this gate is permission to investigate a meaningful comparator, not a general capability claim.

The task-specific local/global attention design, parameter counts, fixed-state versus retained-sequence storage difference, and exact fast/full computation checks are unchanged from v10. Original source modules are imported by hash. Checkpoints contain full model state and config, but not optimizer/RNG state for exact continuation.

## Final results and checkpoint verification

All four runs completed all six required intervals through step 6,000. I independently verified all 24 checkpoint file hashes, loaded ordered tensor hashes, step/seed/rate metadata, and recorded exact reload assertions. Source hashes, source protocol hashes, all shared training digests, pooled metrics, and gate flags match. Selection is the minimum final-step CE, not the best intermediate epoch.

Transformer selected learning rate 0.003, achieved 100% pooled validation accuracy, and passed the gate. RNN selected learning rate 0.001, achieved 6.7708% pooled validation accuracy, and failed the gate. The RNN failure remains part of the record. These are final validation findings, not final test performance. A separately predeclared held-out replication is required for a stronger comparative claim. No training was repeated by this audit.
