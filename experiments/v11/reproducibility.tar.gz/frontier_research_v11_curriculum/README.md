# v11 curriculum adequacy pilot

This is an explicitly exploratory, validation-only response to v10 optimization failure. It is **not** a new held-out benchmark result and does not change v10's frozen result.

Four fresh training runs: each architecture at learning rates0.001 and0.003, seed101. Every run receives6000 updates of8 examples with identical data and token counts. Curriculum:1000updates at length64/factcount4;1000 at length128/factcount4or8;4000 at length128/256/512 and factcount4/8/16. Adam defaults, gradient norm clipping1, float32 deterministic PyTorch2.6.0+cpu, one thread. Architectures are unchanged from v10.

Every1000updates, save the full state dictionary and run a fixed fresh validation set (128cases per length128/256/512 × factcount4/8/16). No intermediate stopping and no epoch selection. Learning rate selection uses **only final6000-step pooled validation cross entropy**, lower learning rate breaks a tie. Mastery is independently assessed for each architecture: pooled validation accuracy≥80% **and** K16/length512 accuracy≥70%. This gate is a training adequacy check, not a capability comparison theorem.

Seeds, source hashes, full schedule and exact per-batch hashes are frozen before training. Original source code is imported from the adjacent v10 directory and identified by hashes. Test seed820000 is reserved but not scored by this pilot. A successful validation result would require separately predeclared final-seed replication before any final test claim. If neither model meets the gate at this fixed budget, the pilot stops and the conclusion is an optimization limitation under these settings.

All24interval checkpoints are saved before process exit and checked for exact reload parity, ordered tensor SHA256 and file SHA256. They contain full model state, not optimizer/RNG continuation state. `results_partial.json` is progress only; `results.json` indicates all four runs completed. Model and dataset assumptions and the task-specific nature of the Transformer comparator remain those documented in v10.

## Reproduction

This directory retains its original frontier_research_v11_curriculum name so the final-stage runner resolves its frozen pilot records. With PyTorch2.6.0+cpu and NumPy installed, run `PYTHONPATH=../v10 python run_curriculum.py`. No test scoring occurs here.
