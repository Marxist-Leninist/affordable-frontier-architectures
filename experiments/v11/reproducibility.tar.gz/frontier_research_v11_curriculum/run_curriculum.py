import run as core
from run import *
def main():
 ep=Path(__file__).parent;core.P=ep
 def ej(name,obj):(ep/name).write_text(json.dumps(obj,indent=2))
 rng=np.random.default_rng(446);schedule=[(64,4)]*1000+[(128,int(rng.choice([4,8]))) for _ in range(1000)]+[(int(rng.choice([128,256,512])),int(rng.choice([4,8,16]))) for _ in range(4000)]
 protocol={'steps':6000,'batch_size':8,'initialization':'fresh models seed101 each architecture/LR','learning_rates':[.001,.003],'learning_rate_selection':'lowest pooled validation CE at final6000; lower LR tie; no epoch selection','schedule':schedule,'schedule_seed':446,'data_seed_base':920000,'training_tokens':sum(l*8 for l,k in schedule),'validation_seed_base':410000,'validation_cases_per_cell':128,'validation_lengths':[128,256,512],'reserved_test_seed_base':820000,'test_evaluation':False,'interval_steps':1000,'gate':{'pooled_validation_accuracy_at_least':.8,'L512_K16_accuracy_at_least':.7,'applies_independently_to_each_architecture':True},'stopping':'complete6000 each run regardless intermediate metrics; no tests; stop at budget if neither meets gate','optimizer':'fresh Adam defaults, clip_norm1.0','threads':1,'dtype':'float32','deterministic':True,'parameters':{a:count(make(a)) for a in ['transformer','rnn']},'source_sha256':{str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in [Path(__file__),P/'run.py',P/'models.py',P/'data.py']}}
 ej('protocol.json',protocol);ej('protocol_sha256.json',{'sha256':hashlib.sha256((ep/'protocol.json').read_bytes()).hexdigest()}); hashes=[]
 for i,(l,k) in enumerate(schedule):
  x,y,_=generate(920000+i,8,l,k);hashes.append(digest(x,y))
 ej('paired_training_batches.json',{'schedule':schedule,'sha256':hashes}); result={'protocol':protocol,'runs':{},'selection':{}}
 for arch in ['transformer','rnn']:
  result['runs'][arch]=[]
  for lr in [.001,.003]:
   torch.manual_seed(101);np.random.seed(101);random.seed(101);m=make(arch);opt=torch.optim.Adam(m.parameters(),lr=lr);start=time.monotonic();losses=[];rec={'learning_rate':lr,'intervals':[]};result['runs'][arch].append(rec)
   for i,(l,k) in enumerate(schedule):
    m.train();x,y,_=generate(920000+i,8,l,k);assert digest(x,y)==hashes[i];opt.zero_grad();loss=nn.functional.cross_entropy(m(torch.from_numpy(x)),torch.from_numpy(y));loss.backward();nn.utils.clip_grad_norm_(m.parameters(),1.);opt.step();losses.append(loss.item())
    if (i+1)%1000==0:
     cfg={'architecture':arch,'learning_rate':lr,'seed':101,'stage':'curriculum_pilot','steps':i+1,'rnn_hidden':hidden() if arch=='rnn' else 0};ck=checkpoint(m,f'curriculum_{arch}_lr{lr}_step{i+1}',cfg,torch.from_numpy(x));val,_=evaluate(m,[128,256,512],128,410000);acc=float(np.mean([a['accuracy'] for a in val.values()]));ce=float(np.mean([a['ce'] for a in val.values()]));info={'step':i+1,'validation':val,'pooled_accuracy':acc,'pooled_ce':ce,'last1000_training_ce':float(np.mean(losses[-1000:])),'seconds':time.monotonic()-start,'checkpoint':ck,'adequacy_gate_pass':acc>=.8 and val['L512_K16']['accuracy']>=.7};rec['intervals'].append(info);ej('results_partial.json',result);print(arch,lr,i+1,'valacc',acc,'K16L512',val['L512_K16']['accuracy'],'valce',ce,'seconds',info['seconds'],flush=True)
  selected=min(result['runs'][arch],key=lambda a:(a['intervals'][-1]['pooled_ce'],a['learning_rate']));result['selection'][arch]={'learning_rate':selected['learning_rate'],'final_accuracy':selected['intervals'][-1]['pooled_accuracy'],'adequacy_gate_pass':selected['intervals'][-1]['adequacy_gate_pass']};ej('selection.json',result['selection'])
 ej('results.json',result);print('DONE',flush=True)
if __name__=='__main__':main()
