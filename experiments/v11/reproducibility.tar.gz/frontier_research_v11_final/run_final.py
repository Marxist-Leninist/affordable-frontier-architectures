import run as core
from run import *
def main():
 ep=Path(__file__).parent;pilot=P.parent/'frontier_research_v11_curriculum';pr=json.loads((pilot/'results.json').read_text());schedule=[tuple(a) for a in pr['protocol']['schedule']];hashes=json.loads((pilot/'paired_training_batches.json').read_text())['sha256'];core.P=ep
 def ej(name,obj):(ep/name).write_text(json.dumps(obj,indent=2))
 protocol={'steps':6000,'batch_size':8,'final_seeds':[1,2,3],'selection_frozen_from':str(pilot/'selection.json'),'selected_learning_rates':{a:s['learning_rate'] for a,s in pr['selection'].items()},'selection_sha256':hashlib.sha256((pilot/'selection.json').read_bytes()).hexdigest(),'schedule':schedule,'training_tokens':sum(l*8 for l,k in schedule),'data_seed_base':920000,'paired_training_hashes_file':str(pilot/'paired_training_batches.json'),'paired_training_hashes_sha256':hashlib.sha256((pilot/'paired_training_batches.json').read_bytes()).hexdigest(),'validation_seed_base':410000,'test_seed_base':820000,'test_lengths':[512,2048,4096],'test_fact_counts':[4,8,16],'test_cases_per_cell':256,'trained_context_length':512,'extrapolation_lengths':[2048,4096],'all_seeds_reported':True,'no_posttest_tuning':True,'checkpoint':'save complete final weights and verify reload before any validation/test scoring','optimizer':'Adam defaults,clip_norm1.0','threads':1,'dtype':'float32','deterministic':True,'source_sha256':{str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in [Path(__file__),P/'run.py',P/'models.py',P/'data.py']}}
 ej('protocol.json',protocol);ej('protocol_sha256.json',{'sha256':hashlib.sha256((ep/'protocol.json').read_bytes()).hexdigest()});result={'protocol':protocol,'final':{}}
 for arch in ['transformer','rnn']:
  result['final'][arch]=[];lr=protocol['selected_learning_rates'][arch]
  for seed in [1,2,3]:
   torch.manual_seed(seed);np.random.seed(seed);random.seed(seed);m=make(arch);opt=torch.optim.Adam(m.parameters(),lr=lr);start=time.monotonic();losses=[]
   for i,(l,k) in enumerate(schedule):
    m.train();x,y,_=generate(920000+i,8,l,k);assert digest(x,y)==hashes[i];opt.zero_grad();loss=nn.functional.cross_entropy(m(torch.from_numpy(x)),torch.from_numpy(y));loss.backward();nn.utils.clip_grad_norm_(m.parameters(),1.);opt.step();losses.append(loss.item())
    if (i+1)%1000==0:print(arch,seed,i+1,'training_ce',float(np.mean(losses[-1000:])),'seconds',time.monotonic()-start,flush=True)
   training_seconds=time.monotonic()-start
   cfg={'architecture':arch,'learning_rate':lr,'seed':seed,'stage':'curriculum_final','steps':6000,'rnn_hidden':hidden() if arch=='rnn' else 0};ck=checkpoint(m,f'final_{arch}_seed{seed}',cfg,torch.from_numpy(x));val,_=evaluate(m,[128,256,512],128,410000);metrics,preds=evaluate(m,[512,2048,4096],256,820000);info={'seed':seed,'learning_rate':lr,'checkpoint':ck,'training_seconds':training_seconds,'total_seconds_including_evaluation':time.monotonic()-start,'last1000_training_ce':float(np.mean(losses[-1000:])),'validation':val,'pooled_validation_accuracy':float(np.mean([a['accuracy'] for a in val.values()])),'test':metrics,'predictions':preds};result['final'][arch].append(info);ej('results_partial.json',result);print('SCORED',arch,seed,{k:a['accuracy'] for k,a in metrics.items()},flush=True)
 ej('results.json',result);print('DONE',flush=True)
if __name__=='__main__':main()
