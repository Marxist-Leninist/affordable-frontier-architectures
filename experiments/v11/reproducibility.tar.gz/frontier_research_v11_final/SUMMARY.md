# Curriculum final replication

Each run:6000updates ×8examples, 11,129,856training tokens. Selected LRs: {'transformer': 0.003, 'rnn': 0.001}

Accuracy below is mean[min,max] across3initialization seeds on the same256test examples/cell. Chance6.25%. Context512is within training range;2048/4096are extrapolation.

## transformer
- L512_K4: 100.00% [100.00, 100.00]; CE0.00005
- L512_K8: 100.00% [100.00, 100.00]; CE0.00005
- L512_K16: 100.00% [100.00, 100.00]; CE0.00005
- L2048_K4: 100.00% [100.00, 100.00]; CE0.00005
- L2048_K8: 100.00% [100.00, 100.00]; CE0.00005
- L2048_K16: 100.00% [100.00, 100.00]; CE0.00005
- L4096_K4: 100.00% [100.00, 100.00]; CE0.00005
- L4096_K8: 100.00% [100.00, 100.00]; CE0.00005
- L4096_K16: 100.00% [100.00, 100.00]; CE0.00005
- Seed1 pooled validation accuracy: 100.00%; training60.9s
- Seed2 pooled validation accuracy: 100.00%; training68.7s
- Seed3 pooled validation accuracy: 100.00%; training70.2s
## rnn
- L512_K4: 6.25% [5.47, 7.42]; CE2.78401
- L512_K8: 6.77% [5.08, 7.81]; CE2.79652
- L512_K16: 5.60% [4.69, 6.64]; CE2.79185
- L2048_K4: 6.38% [5.86, 6.64]; CE2.79793
- L2048_K8: 6.38% [5.08, 8.20]; CE2.79010
- L2048_K16: 4.95% [3.91, 5.86]; CE2.80192
- L4096_K4: 5.86% [3.52, 7.42]; CE2.79025
- L4096_K8: 6.90% [6.64, 7.03]; CE2.79284
- L4096_K16: 5.73% [4.69, 6.25]; CE2.78983
- Seed1 pooled validation accuracy: 5.21%; training89.4s
- Seed2 pooled validation accuracy: 6.34%; training85.8s
- Seed3 pooled validation accuracy: 5.90%; training88.4s

All6final checkpoints saved before scoring, exact reload parity, file hashes reverified after completion.

Interpretation: this is synthetic associative recall using a task-specific position-free local/global Transformer, not a production Transformer benchmark. The Transformer retains the sequence (O(length) memory); the RNN carries fixed state. Parameter counts and training data/token budgets are closely matched, but memory/compute/inductive biases are not. Failure to learn under this protocol does not prove intrinsic memory incapacity. Three initialization seeds share the same train and test datasets, so they do not provide three independent datasets.

History is retained: original600-step v10 was chance for both;2400additional same-distribution steps did not meet adequacy; a separately predeclared curriculum validation pilot established Transformer trainability. These final runs used fresh initialization and an untouched test seed after final-step validation LR selection. No failed final seeds were excluded.