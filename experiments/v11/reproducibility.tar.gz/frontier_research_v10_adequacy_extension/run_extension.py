import run as core
from run import *
def main():
 original=json.loads((P/'results.json').read_text());ep=Path(__file__).parent;ep.mkdir(exist_ok=True);core.P=ep
 def ej(name,obj): (ep/name).write_text(json.dumps(obj,indent=2))
 rng=np.random.default_rng(445);schedule=[(int(rng.choice([128,256,512])),int(rng.choice([4,8,16]))) for _ in range(2400)]
 protocol={'additional_steps':2400,'batch_size':8,'schedule_seed':445,'schedule':schedule,'data_seed_base':910000,'total_additional_tokens':sum(l*8 for l,k in schedule),'initialization':'selected seed101 tuning weights; fresh Adam; original optimizer/RNG not restored','learning_rates':original['selection'],'checkpoints_and_validation_steps':[600,1200,1800,2400],'validation':'original validation, seed_base310000,128/cell at128/256/512','test_evaluation':False,'gate':{'pooled_validation_accuracy_at_least':.8,'L512_K16_accuracy_at_least':.7},'stopping':'complete2400steps regardless intermediate metrics','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()};ej('protocol.json',protocol)
 hashes=[]
 for i,(l,k) in enumerate(schedule):
  x,y,_=generate(910000+i,8,l,k);hashes.append(digest(x,y))
 ej('paired_training_batches.json',hashes);result={'protocol':protocol,'runs':{}}
 for arch in ['transformer','rnn']:
  lr=original['selection'][arch];picked=next(a for a in original['tuning'][arch] if a['lr']==lr);m=make(arch);saved=torch.load(picked['checkpoint']['path'],weights_only=True);assert statehash(saved['state_dict'])==picked['checkpoint']['state_sha256'];m.load_state_dict(saved['state_dict']);opt=torch.optim.Adam(m.parameters(),lr=lr);start=time.monotonic();losses=[];result['runs'][arch]={'source_checkpoint':picked['checkpoint'],'intervals':[]}
  for i,(l,k) in enumerate(schedule):
   m.train();x,y,_=generate(910000+i,8,l,k);assert digest(x,y)==hashes[i];opt.zero_grad();loss=nn.functional.cross_entropy(m(torch.from_numpy(x)),torch.from_numpy(y));loss.backward();nn.utils.clip_grad_norm_(m.parameters(),1.);opt.step();losses.append(loss.item())
   if (i+1)%600==0:
    cfg={'architecture':arch,'learning_rate':lr,'seed':101,'stage':'extension_pilot','additional_steps':i+1,'rnn_hidden':hidden() if arch=='rnn' else 0};ck=checkpoint(m,f'extension_pilot_{arch}_step{i+1}',cfg,torch.from_numpy(x));val,_=evaluate(m,[128,256,512],128,310000);acc=float(np.mean([a['accuracy'] for a in val.values()]));ce=float(np.mean([a['ce'] for a in val.values()]));info={'additional_step':i+1,'validation':val,'pooled_accuracy':acc,'pooled_ce':ce,'last600_training_ce':float(np.mean(losses[-600:])),'seconds':time.monotonic()-start,'checkpoint':ck,'adequacy_gate_pass':acc>=.8 and val['L512_K16']['accuracy']>=.7};result['runs'][arch]['intervals'].append(info);ej('results_partial.json',result);print(arch,i+1,'valacc',acc,'valce',ce,'seconds',info['seconds'],flush=True)
 ej('results.json',result);print('DONE',flush=True)
if __name__=='__main__':main()
