# v10 validation-only adequacy extension

This preserves original v10 and continues only the two validation-selected seed101 tuning checkpoints. Both receive2400 additional updates of batch8, identical fresh data and schedules, same original train length/fact-count distribution, selected learning rates unchanged. Adam is restarted with fresh state; this is **not** a bit-exact continuation of the original optimizer. Original weights remain intact.

Before execution, the mastery gate was fixed as pooled validation accuracy≥80% **and** K16/L512 accuracy≥70%. The same gate is applied independently to each model. It is an adequacy diagnostic, not a winner criterion or a capacity theorem. All2400 updates complete regardless of intermediate validation metrics. Checkpoints and validation are captured at600,1200,1800,2400 updates. No held-out test scoring occurs in this extension.

The extension uses the original validation set, so its results remain validation measurements and are not fresh independent test evidence. A failure indicates failure to optimize this protocol, not inability of the architecture to represent the task. The original600-step results must not be replaced with these curves without disclosing the extension.

`protocol.json` and `source_protocol_sha256.json` identify the fixed plan and source. `paired_training_batches.json` identifies exact shared minibatches. Every saved checkpoint has ordered tensor SHA256, file SHA256 and exact reload-logit parity in the results. Final `results.json` indicates completion.

## Reproduction

First reproduce v10 to materialize its selected checkpoints. From this directory with PyTorch2.6.0+cpu and NumPy installed, run `PYTHONPATH=../v10 python run_extension.py`. The standalone published script omits a non-executable introductory comment; publication_manifest.json records as-run and published hashes and the unchanged executable AST hash. Historical results retain their original as-run source hash.
